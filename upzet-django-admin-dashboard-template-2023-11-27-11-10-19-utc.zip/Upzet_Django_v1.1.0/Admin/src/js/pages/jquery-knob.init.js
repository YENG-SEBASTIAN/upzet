/*
Template Name: Upzet - Responsive Bootstrap 4 Admin Dashboard
Author: Themesdesign
Website: https://themesdesign.in/
File: Knob Chart
*/

$(function () {
  $('[data-plugin="knob"]').knob();
});