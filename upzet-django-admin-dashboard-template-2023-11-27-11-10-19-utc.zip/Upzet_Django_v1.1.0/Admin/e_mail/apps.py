from django.apps import AppConfig


class EMailConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'e_mail'
